﻿using System;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.IO;
namespace WindowsFormsApp4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int height, width;
                if (!int.TryParse(textBox1.Text, out height) | !int.TryParse(textBox1.Text, out width))
                {
                    throw new IOException("Неправильный ввод");
                }
                string uri = "http://127.0.0.1/katyzina/kurs/kursovaya.php?h=" + height + "&w=" + width;
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(uri);
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                StreamReader reader = new StreamReader(response.GetResponseStream(), Encoding.UTF8);
                Console.WriteLine(reader.ReadToEnd());
                Console.ReadLine();
                pictureBox1.Load("http://127.0.0.1/katyzina/kurs/2.png");
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
    }
}
